package com.focusglass.pomodoro

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF171B29)
private val Purple = Color(0xFFB6A0FF)
private val Mint = Color(0xFF8DE7D0)
private val Muted = Color(0xFF9CA3B8)
private val White = Color(0xFFF5F4FF)

class MainActivity : ComponentActivity() {
    private val askNotification = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { FocusGlassApp(this) }
    }

    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("focusglass_timer", "Timer alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun notifyFinished(isFocus: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val title = if (isFocus) "Focus session complete" else "Break complete"
        val body = if (isFocus) "Nice work. Time for a break." else "Break's over. Ready to focus?"
        val notification = NotificationCompat.Builder(this, "focusglass_timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify(if (isFocus) 1 else 2, notification)
        }
    }
}

private data class StudyTask(val id: Long, val title: String, val done: Boolean)
private fun Context.prefs() = getSharedPreferences("focusglass", Context.MODE_PRIVATE)

@Composable
private fun FocusGlassApp(context: MainActivity) {
    val prefs = remember { context.prefs() }
    var focusMinutes by remember { mutableIntStateOf(prefs.getInt("focus", 25)) }
    var breakMinutes by remember { mutableIntStateOf(prefs.getInt("break", 5)) }
    var isFocus by remember { mutableStateOf(true) }
    var remaining by remember { mutableLongStateOf(focusMinutes * 60_000L) }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var totalFocus by remember { mutableIntStateOf(prefs.getInt("totalFocus", 0)) }
    var taskText by remember { mutableStateOf("") }
    var tasks by remember { mutableStateOf(loadTasks(prefs.getString("tasks", "[]") ?: "[]")) }
    var showSettings by remember { mutableStateOf(false) }
    var focusInput by remember { mutableStateOf(focusMinutes.toString()) }
    var breakInput by remember { mutableStateOf(breakMinutes.toString()) }
    var timer by remember { mutableStateOf<CountDownTimer?>(null) }

    fun resetTimer() {
        timer?.cancel()
        running = false
        remaining = (if (isFocus) focusMinutes else breakMinutes) * 60_000L
    }
    fun startTimer() {
        if (running) return
        if (remaining <= 0L) remaining = (if (isFocus) focusMinutes else breakMinutes) * 60_000L
        running = true
        timer = object : CountDownTimer(remaining, 1000) {
            override fun onTick(millisUntilFinished: Long) { remaining = millisUntilFinished }
            override fun onFinish() {
                running = false
                remaining = 0L
                if (isFocus) {
                    completed += 1
                    totalFocus += focusMinutes
                    prefs.edit().putInt("completed", completed).putInt("totalFocus", totalFocus).apply()
                }
                context.notifyFinished(isFocus)
            }
        }.start()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            secondary = Mint, onBackground = White, onSurface = White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17142A), Bg, Color(0xFF071B20)))
            )
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("FOCUS GLASS", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("Make time count.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = { showSettings = true; focusInput = focusMinutes.toString(); breakInput = breakMinutes.toString() }) {
                            Text("Settings", color = Purple)
                        }
                    }
                }
                item {
                    GlassCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            FilterChip(selected = isFocus, onClick = {
                                if (!running) { isFocus = true; remaining = focusMinutes * 60_000L }
                            }, label = { Text("Focus") })
                            Spacer(Modifier.width(10.dp))
                            FilterChip(selected = !isFocus, onClick = {
                                if (!running) { isFocus = false; remaining = breakMinutes * 60_000L }
                            }, label = { Text("Break") })
                        }
                        Spacer(Modifier.height(22.dp))
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(228.dp).border(8.dp, Color(0xFF35304D), CircleShape)
                                    .border(2.dp, if (isFocus) Purple else Mint, CircleShape).padding(22.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(if (isFocus) "TIME TO FOCUS" else "TAKE A BREATHER", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                                    Text(formatTime(remaining), color = White, fontSize = 43.sp, fontWeight = FontWeight.Light)
                                    Text(if (running) "Session in progress" else "Ready when you are", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            FilledTonalButton(onClick = { timer?.cancel(); running = false; remaining = (if (isFocus) focusMinutes else breakMinutes) * 60_000L }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Reset")
                                Spacer(Modifier.width(6.dp)); Text("Reset")
                            }
                            Spacer(Modifier.width(12.dp))
                            Button(onClick = {
                                if (running) { timer?.cancel(); running = false }
                                else startTimer()
                            }, colors = ButtonDefaults.buttonColors(containerColor = if (isFocus) Purple else Mint, contentColor = Color(0xFF10111A))) {
                                Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(6.dp)); Text(if (running) "Pause" else "Start", fontWeight = FontWeight.Bold)
                            }
                        }
                        if (remaining == 0L && !running) {
                            Spacer(Modifier.height(8.dp))
                            Text("Session finished. Switch Focus/Break or press Start to run again.", color = Mint, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("SESSIONS", completed.toString(), "completed")
                        StatCard("FOCUS TIME", "${totalFocus}m", "total")
                    }
                }
                item {
                    GlassCard {
                        Text("Study tasks", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Text("Keep your next step visible.", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = taskText, onValueChange = { taskText = it },
                                modifier = Modifier.weight(1f), placeholder = { Text("Add a task") },
                                singleLine = true, shape = RoundedCornerShape(14.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = {
                                val clean = taskText.trim()
                                if (clean.isNotEmpty()) {
                                    tasks = tasks + StudyTask(System.currentTimeMillis(), clean, false)
                                    taskText = ""; saveTasks(prefs, tasks)
                                }
                            }) { Icon(Icons.Default.Add, contentDescription = "Add task", tint = Mint) }
                        }
                        if (tasks.isEmpty()) Text("No tasks yet — add one above.", color = Muted, fontSize = 13.sp)
                        tasks.forEach { task ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    tasks = tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }
                                    saveTasks(prefs, tasks)
                                }) { Icon(if (task.done) Icons.Default.Check else Icons.Default.Add, contentDescription = if (task.done) "Mark incomplete" else "Mark complete", tint = if (task.done) Mint else Purple) }
                                Text(task.title, Modifier.weight(1f), color = if (task.done) Muted else White)
                                IconButton(onClick = { tasks = tasks.filterNot { it.id == task.id }; saveTasks(prefs, tasks) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = Muted)
                                }
                            }
                        }
                    }
                }
                item {
                    Text("Private by design • Your stats and tasks stay on this device.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Timer settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choose durations in minutes. Changes apply to the next reset.", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(value = focusInput, onValueChange = { focusInput = it.filter(Char::isDigit).take(3) }, label = { Text("Focus minutes") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(value = breakInput, onValueChange = { breakInput = it.filter(Char::isDigit).take(3) }, label = { Text("Break minutes") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val f = focusInput.toIntOrNull()?.coerceIn(1, 180) ?: 25
                    val b = breakInput.toIntOrNull()?.coerceIn(1, 60) ?: 5
                    focusMinutes = f; breakMinutes = b
                    prefs.edit().putInt("focus", f).putInt("break", b).apply()
                    timer?.cancel(); running = false
                    remaining = (if (isFocus) focusMinutes else breakMinutes) * 60_000L
                    showSettings = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }

    DisposableEffect(Unit) { onDispose { timer?.cancel() } }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(0xCC24263A), Color(0xB315202C))), RoundedCornerShape(26.dp))
            .border(1.dp, Color(0x55C9C0FF), RoundedCornerShape(26.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
private fun RowScope.StatCard(title: String, value: String, caption: String) {
    Column(
        Modifier.weight(1f).background(Color(0xAA171B29), RoundedCornerShape(20.dp))
            .border(1.dp, Color(0x44B6A0FF), RoundedCornerShape(20.dp)).padding(16.dp)
    ) {
        Text(title, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Text(value, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(caption, color = Muted, fontSize = 12.sp)
    }
}

private fun formatTime(ms: Long): String {
    val seconds = (ms.coerceAtLeast(0L) / 1000L)
    return String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60)
}

private fun loadTasks(raw: String): List<StudyTask> = try {
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val item = array.getJSONObject(i)
        StudyTask(item.optLong("id"), item.optString("title"), item.optBoolean("done"))
    }
} catch (_: Exception) { emptyList() }

private fun saveTasks(prefs: android.content.SharedPreferences, tasks: List<StudyTask>) {
    val array = JSONArray()
    tasks.forEach {
        array.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done))
    }
    prefs.edit().putString("tasks", array.toString()).apply()
}
