# Focus Glass Pomodoro

A brand-new native Android Pomodoro app built with Kotlin and Jetpack Compose. It is not a website wrapper.

## Included
- Dark glassmorphism UI
- Focus/break sessions and customizable durations
- Start, pause, reset controls
- Local session and focus-minute stats
- Local task list with complete/delete
- Completion notifications (permission required on Android 13+)
- Offline-first storage using SharedPreferences
- GitHub Actions workflow to build a debug APK for free

## Build from an Android phone using GitHub Actions
1. Create a GitHub account if needed.
2. Create a new **public or private** repository named `focus-glass-pomodoro`.
3. Upload the contents of this folder to the repository (not just the ZIP file). Keep the folder structure.
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. Select **Build Android APK** and press **Run workflow**. Or push/commit to `main`.
6. Open the completed workflow run and download the `FocusGlass-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow installing apps from that source.

## Notes
- This is a debug APK for personal testing, not a Play Store release.
- Timer notifications are posted when the timer is running while the app process remains alive. Android may stop background work if the app is force-stopped or the system aggressively manages it.
- Current stats count completed focus sessions and focus minutes, stored locally on this device.
- No internet connection is needed by the app itself after installation.
